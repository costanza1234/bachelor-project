esplorazione proof of concept,
toy prototype,
riusciamo a raccogliere dati con un gioco?
che tipo di gioco?
cosa vuole la comunita di ricerca?
come lo rendiamo utilizzabile dai bambini?

expert evaluation / heuristic evaluation degli esperti del gioco metodo walkthrough
