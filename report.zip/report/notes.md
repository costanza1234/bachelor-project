exploration of the domain,
proof of concept,
toy prototype,
what kind of data do the reasearchers want?
can we collect data with a game?
what kind of game?
what does the research community want?
how do we make it usable by children?

expert evaluation / heuristic evaluation degli esperti del gioco metodo walkthrough
